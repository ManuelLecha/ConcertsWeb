from db import db

####ARTIST
ART = 'artist'
ARTS = 'artists'
##########
#####ATTR
ID = 'id'
NM = 'name'
CTRY = 'country'
GNR = 'genre'
#######

genres = ('REGGAE', 'POP', 'TRAP', 'HIP HOP', 'ROCK', 'INDIE', 'HEAVY', 'ELECTRONIC', 'OTHER')

class ArtistModel(db.Model):
    __tablename__ = ARTS #This is table name

    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(30), unique = True, nullable=False)
    country = db.Column(db.String(30), nullable=False)
    genre = db.Column(db.Enum(*genres), nullable=False)

    def __init__(self, name, country, genre):
        self.name = name
        self.country = country
        self.genre = genre

    def json(self):
        return {
            ART: {
                ID: self.id,
                NM: self.name,
                CTRY: self.country,
                GNR: self.genre
            }
        }

    def save_to_db(self):
        db.session.add(self)
        db.session.commit()

    def delete_from_db(self):
        db.session.delete(self)
        db.session.commit()

    def modify_from_db(self, name, country, genre):
        self.name = name
        self.country = country
        self.genre = genre
        db.session.add(self)
        db.session.commit()

    @classmethod
    def find_by_id(cls, aid):
        return ArtistModel.query.filter_by(id=aid).first()

    @classmethod
    def find_by_name(cls, aname):
        return ArtistModel.query.filter_by(name=aname).first()

    @classmethod
    def find_by_country(cls, acountry):
        return ArtistModel.query.filter_by(country=acountry).all()

    @classmethod
    def find_by_genre(cls, agenre):
        return ArtistModel.query.filter_by(genre=agenre).all()

    @classmethod
    def return_all(cls):
        return {ARTS:
                    [a.json()[ART] for a in ArtistModel.query.all()]
               }