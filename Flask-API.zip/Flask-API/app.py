from flask import Flask
from flask_restful import Resource, Api, reqparse
from db import db
from flask_migrate import Migrate
from models.artist import ArtistModel, NM, CTRY, GNR, genres
from models.event import EventModel, PLC, CTY, DATE, PRC, TAT, EVNTS

####PROTOCOL
MSG = 'message'
########

app = Flask(__name__)
api = Api(app)
app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///data.db'
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False
migrate = Migrate(app, db)
db.init_app(app)

class Artist(Resource):

    def get(self, id):
        artist = ArtistModel.find_by_id(id)
        if artist:
            return artist.json(), 200
        else:
            return {MSG: "Artist not found"}, 404

    def post(self):
        parser = reqparse.RequestParser()  # create parameters parser from request
        # define al input parameters need and its type
        parser.add_argument(NM, type=str, required=True, help="Artistic name of the artist")
        parser.add_argument(CTRY, type=str, required=True, help="Country nationality of the artist")
        parser.add_argument(GNR, type=str, required=True, help="Main genre of the artist")
        data = parser.parse_args()

        if ArtistModel.find_by_name(data[NM]):
            return {MSG: "Artist already in the data base"}, 409

        if data[GNR] not in genres:
            return {MSG: "Genre not allowed"}, 400

        try:
            new_artist = ArtistModel(data[NM], data[CTRY], data[GNR])
            new_artist.save_to_db()
            return new_artist.json(), 201
        except:
            return {MSG: "Error Description"}, 500

    def delete(self, id):
        artist = ArtistModel.find_by_id(id)
        if artist:
            artist.delete_from_db()
            return {MSG: "Artist deleted successfully"}, 200
        else:
            return {MSG: "Artist not found"}, 404


    def put(self, id):
        artist = ArtistModel.find_by_id(id)

        parser = reqparse.RequestParser()  # create parameters parser from request
        # define al input parameters need and its type
        parser.add_argument(NM, type=str, required=True, help="Artistic name of the artist")
        parser.add_argument(CTRY, type=str, required=True, help="Country nationality of the artist")
        parser.add_argument(GNR, type=str, required=True, help="Main genre of the artist")
        data = parser.parse_args()

        if not artist:
            return {MSG: "Artist not found"}, 404

        if data[GNR] not in genres:
            return {MSG: "Genre not allowed"}, 400

        aux_artist = ArtistModel.find_by_name(data[NM])
        if aux_artist and aux_artist.id != id:
            return {MSG: "Artist already in the data base with another ID"}, 409

        try:
            artist.modify_from_db(data[NM], data[CTRY], data[GNR])
            return artist.json(), 200
        except:
            return {MSG: "Error Description"}, 500


api.add_resource(Artist, '/artist/<int:id>', '/artist')


class ArtistList(Resource):

    def get(self):
        return ArtistModel.return_all(), 200


api.add_resource(ArtistList, '/artists')


class Event(Resource):

    def get(self, id):
        event = EventModel.find_by_id(id)
        if event:
            return event.json(), 200
        else:
            return {MSG: "Event not found"}, 404

    def post(self):
        parser = reqparse.RequestParser()  # create parameters parser from request
        # define al input parameters need and its type
        parser.add_argument(NM, type=str, required=True, help="Name of the event")
        parser.add_argument(PLC, type=str, required=True, help="Place or area where the event takes place")
        parser.add_argument(CTY, type=str, required=True, help="City that holds the event")
        parser.add_argument(DATE, type=str, required=True, help="Date when the event takes place")
        parser.add_argument(PRC, type=int, required=True, help="Weighted average price of the event")
        parser.add_argument(TAT, type=int, required=True, help="Number of people that can attend the event")
        data = parser.parse_args()

        if EventModel.find_by_uniqueness(data[NM], data[DATE], data[CTY]):
            return {MSG: "Event already in the data base"}, 409

        if data[PRC] < 0:
            return {MSG: "Negative price not allowed"}

        if data[TAT] < 0:
            return {MSG: "Negative number of tickets not possible"}

        try:
            new_event = EventModel(data[NM], data[PLC], data[CTY], data[DATE], data[PRC], data[TAT])
            new_event.save_to_db()
            return new_event.json(), 201
        except:
            return {MSG: "Error Description"}, 500

    def delete(self, id):
        event = EventModel.find_by_id(id)
        if event:
            event.delete_from_db()
            return {MSG: "Event deleted successfully"}, 200
        else:
            return {MSG: "Event not found"}, 404


    def put(self, id):
        event = EventModel.find_by_id(id)

        parser = reqparse.RequestParser()  # create parameters parser from request
        # define al input parameters need and its type
        parser.add_argument(NM, type=str, required=True, help="Name of the event")
        parser.add_argument(PLC, type=str, required=True, help="Place or area where the event takes place")
        parser.add_argument(CTY, type=str, required=True, help="City that holds the event")
        parser.add_argument(DATE, type=str, required=True, help="Date when the event takes place")
        parser.add_argument(PRC, type=int, required=True, help="Weighted average price of the event")
        parser.add_argument(TAT, type=int, required=True, help="Number of people that can attend the event")
        data = parser.parse_args()

        if not event:
            return {MSG: "Event not found"}, 404

        if data[PRC] < 0:
            return {MSG: "Negative price not allowed"}

        if data[TAT] < 0:
            return {MSG: "Negative number of tickets not possible"}

        aux_event = EventModel.find_by_uniqueness(data[NM], data[DATE], data[CTY])
        if aux_event and aux_event.id != id:
            return {MSG: "Event already in the data base with another ID"}, 409

        try:
            event.modify_from_db(data[NM], data[PLC], data[CTY], data[DATE], data[PRC], data[TAT])
            return event.json(), 200
        except:
            return {MSG: "Error Description"}, 500


api.add_resource(Event, '/event/<int:id>', '/event')


class EventList(Resource):

    def get(self):
        return EventModel.return_all(), 200


api.add_resource(EventList, '/events')


class EventArtistsList(Resource):

    def get(self, id):
        event = EventModel.find_by_id(id)
        if event:
            return event.get_artists(), 200
        else:
            return {MSG: "Event not found"}, 404


api.add_resource(EventArtistsList, '/event/<int:id>/artists')


class EventArtist(Resource):

    def get(self, id_event, id_artist):
        artist = ArtistModel.query.join(ArtistModel.events).filter(EventModel.id == id_event).filter(ArtistModel.id == id_artist).first()
        if not artist:
            return {MSG: "Artist or event not found"}, 404
        return artist.json()

    def post(self, id_event):
        event = EventModel.find_by_id(id_event)
        if not event:
            return {MSG: "Event not found"}, 404

        parser = reqparse.RequestParser()  # create parameters parser from request
        # define al input parameters need and its type
        parser.add_argument(NM, type=str, required=True, help="Artistic name of the artist")
        parser.add_argument(CTRY, type=str, required=True, help="Country nationality of the artist")
        parser.add_argument(GNR, type=str, required=True, help="Main genre of the artist")
        data = parser.parse_args()

        artist = ArtistModel.find_by_name(data[NM])
        if artist and artist.country == data[CTRY] and artist.genre == data[GNR]:
            event.artists.append(artist)
            event.save_to_db()
            return event.json(), 200
        elif not artist:
            if data[GNR] not in genres:
                return {MSG: "Genre not allowed"}, 400

            artist = ArtistModel(data[NM], data[CTRY], data[GNR])
            artist.save_to_db()
            event.artists.append(artist)
            event.save_to_db()
            return event.json(), 200
        else:
            return {MSG: "Artist already exist with other parameters"}, 409

    def delete(self, id_event, id_artist):
        event = EventModel.find_by_id(id_event)
        artist = ArtistModel.query.join(ArtistModel.events).filter(EventModel.id == id_event).filter(ArtistModel.id == id_artist).first()
        if not artist:
            return {MSG: "Artist or event not found"}, 404
        event.artists.remove(artist)
        return {MSG: "Artist deleted successfully"}


api.add_resource(EventArtist, '/event/<int:id_event>/artist/<int:id_artist>','/event/<int:id_event>/artist')


class ArtistEventsList(Resource):

    def get(self, aid):
        artist = ArtistModel.find_by_id(aid)
        if not artist:
            return {MSG: "Artist not found"}, 404

        return {EVNTS:
                    [e.json() for e in EventModel.query.filter(EventModel.artists.any(id=aid)).all()]
               }


api.add_resource(ArtistEventsList, '/artist/<int:aid>/events')

if __name__ == '__main__':
    app.run(port=5000, debug=True)  # This command should be modified before deploying our application
